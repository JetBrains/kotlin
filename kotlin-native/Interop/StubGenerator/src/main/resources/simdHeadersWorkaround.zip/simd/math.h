#ifndef SIMD_MATH_HEADER
#define SIMD_MATH_HEADER
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector_make.h>
#include <simd/logic.h>
#ifdef __cplusplus
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 5
#endif
#ifdef __cplusplus
#include <cmath>
#if SIMD_LIBRARY_VERSION >= 5
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 1
#endif
#if SIMD_LIBRARY_VERSION >= 5
#endif
#else
#include <tgmath.h>
#endif /* !__cplusplus */
#pragma mark - fabs implementation
#pragma mark - isfinite implementation
#pragma mark - isinf implementation
#pragma mark - isnan implementation
#pragma mark - isnormal implementation
#pragma mark - fmin, fmax implementation
#if defined __SSE2__
#elif defined __arm64__
#elif defined __arm__ && __FINITE_MATH_ONLY__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__ && !__FINITE_MATH_ONLY__
#elif defined __SSE2__ && __FINITE_MATH_ONLY__
#elif defined __SSE2__
#elif defined __arm64__
#elif defined __arm__ && __FINITE_MATH_ONLY__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__ && !__FINITE_MATH_ONLY__
#elif defined __AVX__ && __FINITE_MATH_ONLY__
#elif defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512DQ__ && !__FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__ && __FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__
#elif defined __SSE2__ && __FINITE_MATH_ONLY__
#elif defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__
#elif defined __AVX__ && __FINITE_MATH_ONLY__
#elif defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512DQ__
#elif defined __x86_64__ && defined __AVX512F__ && __FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#elif defined __arm__ && __FINITE_MATH_ONLY__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__ && !__FINITE_MATH_ONLY__
#elif defined __SSE2__ && __FINITE_MATH_ONLY__
#elif defined __SSE2__
#elif defined __arm64__
#elif defined __arm__ && __FINITE_MATH_ONLY__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__ && !__FINITE_MATH_ONLY__
#elif defined __AVX__ && __FINITE_MATH_ONLY__
#elif defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512DQ__ && !__FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__ && __FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__
#elif defined __SSE2__ && __FINITE_MATH_ONLY__
#elif defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX512DQ__ && defined __AVX512VL__
#elif defined __AVX__ && __FINITE_MATH_ONLY__
#elif defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512DQ__
#elif defined __x86_64__ && defined __AVX512F__ && __FINITE_MATH_ONLY__
#elif defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - copysign implementation
#pragma mark - sqrt implementation
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - ceil, floor, rint, trunc implementation
#if defined __arm64__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __SSE4_1__
#elif defined __arm64__
#elif defined __arm__ && SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - sine, cosine implementation
#if SIMD_LIBRARY_VERSION >= 3
#elif SIMD_LIBRARY_VERSION == 1
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#elif SIMD_LIBRARY_VERSION == 1
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#elif SIMD_LIBRARY_VERSION == 1
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#elif SIMD_LIBRARY_VERSION == 1
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - acos implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - asin implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - atan implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - tan implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - cospi implementation
#if SIMD_LIBRARY_VERSION >= 1
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#endif /* SIMD_LIBRARY_VERSION */
#pragma mark - sinpi implementation
#if SIMD_LIBRARY_VERSION >= 1
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#endif /* SIMD_LIBRARY_VERSION */
#pragma mark - tanpi implementation
#if SIMD_LIBRARY_VERSION >= 1
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#endif /* SIMD_LIBRARY_VERSION */
#pragma mark - acosh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - asinh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - atanh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - cosh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - sinh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - tanh implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - exp implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - exp2 implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - exp10 implementation
#if SIMD_LIBRARY_VERSION >= 1
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#endif /* SIMD_LIBRARY_VERSION */
#pragma mark - expm1 implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - log implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - log2 implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - log10 implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - log1p implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - cbrt implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - erf implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - erfc implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - tgamma implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - round implementation
#if SIMD_LIBRARY_VERSION >= 3
#if defined __arm64__
#else
#endif
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#if defined __arm64__
#else
#endif
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - atan2 implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - hypot implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - pow implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - fmod implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - remainder implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma mark - nextafter implementation
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 5
#pragma mark - sincos implementation
#pragma mark - sincospi implementation
#endif // SIMD_LIBRARY_VERSION >= 5
#pragma mark - lgamma implementation
#if SIMD_LIBRARY_VERSION >= 4
#else
#endif
#if SIMD_LIBRARY_VERSION >= 4 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 4 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 4
#else
#endif
#if SIMD_LIBRARY_VERSION >= 4 && defined __x86_64__ && defined __AVX2__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 4 && defined __x86_64__ && defined __AVX512F__
#else
#endif
#if defined __arm64__ || defined __ARM_VFPV4__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __arm64__ || defined __ARM_VFPV4__
#elif (defined __i386__ || defined __x86_64__) && defined __FMA__
#elif SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if (defined __i386__ || defined __x86_64__) && defined __FMA__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 3
#endif
#if defined __arm64__
#elif (defined __i386__ || defined __x86_64__) && defined __FMA__
#elif SIMD_LIBRARY_VERSION >= 3
#else
#endif
#if (defined __i386__ || defined __x86_64__) && defined __FMA__
#else
#endif
#if defined __x86_64__ && defined __AVX512F__
#else
#endif
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#pragma STDC FP_CONTRACT ON
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* SIMD_MATH_HEADER */
