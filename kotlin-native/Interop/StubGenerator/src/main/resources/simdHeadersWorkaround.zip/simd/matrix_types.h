#ifndef SIMD_MATRIX_TYPES_HEADER
#define SIMD_MATRIX_TYPES_HEADER
#include <simd/types.h>
#include <simd/vector_make.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
typedef simd_float2x2 matrix_float2x2;
typedef simd_float3x2 matrix_float3x2;
typedef simd_float4x2 matrix_float4x2;
typedef simd_float2x3 matrix_float2x3;
typedef simd_float3x3 matrix_float3x3;
typedef simd_float4x3 matrix_float4x3;
typedef simd_float2x4 matrix_float2x4;
typedef simd_float3x4 matrix_float3x4;
typedef simd_float4x4 matrix_float4x4;
typedef simd_double2x2 matrix_double2x2;
typedef simd_double3x2 matrix_double3x2;
typedef simd_double4x2 matrix_double4x2;
typedef simd_double2x3 matrix_double2x3;
typedef simd_double3x3 matrix_double3x3;
typedef simd_double4x3 matrix_double4x3;
typedef simd_double2x4 matrix_double2x4;
typedef simd_double3x4 matrix_double3x4;
typedef simd_double4x4 matrix_double4x4;
#ifdef __cplusplus
#if defined SIMD_MATRIX_HEADER
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if defined SIMD_MATRIX_HEADER
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if defined SIMD_MATRIX_HEADER
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if defined SIMD_MATRIX_HEADER
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if __has_feature(cxx_delegating_constructors)
#endif
#if defined SIMD_MATRIX_HEADER
#endif
#endif /* __cplusplus */
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* SIMD_MATRIX_TYPES_HEADER */
