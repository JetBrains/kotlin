#ifndef __SIMD_EXTERN_HEADER__
#define __SIMD_EXTERN_HEADER__
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/types.h>
#ifdef __cplusplus
#endif
#pragma mark - geometry
#if SIMD_LIBRARY_VERSION >= 2
#endif /* SIMD_LIBRARY_VERSION */
#pragma mark - matrix
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* __SIMD_EXTERN_HEADER__ */
