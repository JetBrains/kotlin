package js

annotation class native()

native fun libf(): Int {
  return 3
}