#ifndef SIMD_LOGIC_HEADER
#define SIMD_LOGIC_HEADER
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector_make.h>
#include <stdint.h>
#ifdef __cplusplus
#endif
#define vector_any simd_any
#define vector_all simd_all
#define vector_select simd_select
#define vector_bitselect simd_bitselect
#ifdef __cplusplus
#endif /* __cplusplus */
#pragma mark - Implementations
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __SSE4_1__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __SSE4_1__
#else
#endif
#if defined __AVX__
#else
#endif
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* __SIMD_LOGIC_HEADER__ */
