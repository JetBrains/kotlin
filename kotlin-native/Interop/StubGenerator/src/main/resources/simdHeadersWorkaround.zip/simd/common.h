#ifndef SIMD_COMMON_HEADER
#define SIMD_COMMON_HEADER
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector_make.h>
#include <simd/logic.h>
#include <simd/math.h>
#ifdef __cplusplus
#endif
#define vector_abs simd_abs
#define vector_max simd_max
#define vector_min simd_min
#define vector_clamp simd_clamp
#define vector_sign simd_sign
#define vector_mix simd_mix
#define simd_lerp simd_mix
#define vector_precise_recip simd_precise_recip
#define vector_fast_recip simd_fast_recip
#define vector_recip simd_recip
#define vector_precise_rsqrt simd_precise_rsqrt
#define vector_fast_rsqrt simd_fast_rsqrt
#define vector_rsqrt simd_rsqrt
#define vector_fract simd_fract
#define vector_step simd_step
#define vector_smoothstep simd_smoothstep
#define vector_reduce_add simd_reduce_add
#define vector_reduce_min simd_reduce_min
#define vector_reduce_max simd_reduce_max
#ifdef __cplusplus
#if __cpp_decltype_auto
#endif
#endif /* __cplusplus */
#pragma mark - Implementation
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm64__
#elif defined __AVX512VL__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512BW__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#if defined __arm__ || defined __arm64__
#elif defined __SSE4_1__
#else
#endif
#if defined __AVX2__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512VL__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if defined __AVX512VL__
#elif defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX512VL__
#elif defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX512VL__
#elif defined __AVX__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if __FAST_MATH__
#else
#endif
#if defined __AVX512VL__
#elif defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX512VL__
#elif defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX512VL__
#elif defined __AVX__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#if defined __arm64__
#else
#endif
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* SIMD_COMMON_HEADER */
