#ifndef __SIMD_GEOMETRY_HEADER__
#define __SIMD_GEOMETRY_HEADER__
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector_types.h>
#include <simd/common.h>
#include <simd/extern.h>
#ifdef __cplusplus
#endif
#define vector_dot simd_dot
#define vector_precise_project simd_precise_project
#define vector_fast_project simd_fast_project
#define vector_project simd_project
#define vector_precise_length simd_precise_length
#define vector_fast_length simd_fast_length
#define vector_length simd_length
#define vector_length_squared simd_length_squared
#define vector_norm_one simd_norm_one
#define vector_norm_inf simd_norm_inf
#define vector_precise_distance simd_precise_distance
#define vector_fast_distance simd_fast_distance
#define vector_distance simd_distance
#define vector_distance_squared simd_distance_squared
#define vector_precise_normalize simd_precise_normalize
#define vector_fast_normalize simd_fast_normalize
#define vector_normalize simd_normalize
#define vector_cross simd_cross
#define vector_reflect simd_reflect
#define vector_refract simd_refract
#if SIMD_LIBRARY_VERSION >= 2
#endif /* SIMD_LIBRARY_VERSION */
#ifdef __cplusplus
#if SIMD_LIBRARY_VERSION >= 2
#endif
#endif /* __cplusplus */
#pragma mark - Implementation
#if defined __FAST_MATH__
#else
#endif
#if defined __FAST_MATH__
#else
#endif
#if defined __FAST_MATH__
#else
#endif
#if defined __FAST_MATH__
#else
#endif
#if SIMD_LIBRARY_VERSION >= 2
#endif /* SIMD_LIBRARY_VERSION */
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* __SIMD_COMMON_HEADER__ */
