#ifndef SIMD_BASE
#define SIMD_BASE
# ifndef __has_attribute
#  define __has_attribute(__x) 0
# endif
# ifndef __has_include
#  define __has_include(__x) 0
# endif
# ifndef __has_feature
#  define __has_feature(__x) 0
# endif
# if __has_attribute(__ext_vector_type__) && __has_attribute(__overloadable__)
#  define SIMD_COMPILER_HAS_REQUIRED_FEATURES 1
# else
#  define SIMD_COMPILER_HAS_REQUIRED_FEATURES 0
# endif
# if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#  if __has_include(<TargetConditionals.h>) && __has_include(<Availability.h>)
#   include <TargetConditionals.h>
#   include <Availability.h>
#   define SIMD_LIBRARY_VERSION 5
#  else /* !__has_include(<TargetContidionals.h>) && __has_include(<Availability.h>) */
#   define SIMD_LIBRARY_VERSION 5
#   define __API_AVAILABLE(...) /* Nothing */
#  endif
#  if defined __ARM_NEON__
#   include <arm_neon.h>
#  elif defined __i386__ || defined __x86_64__
#   include <immintrin.h>
#  endif
#  if __has_attribute(__always_inline__)
#   define SIMD_INLINE  __attribute__((__always_inline__))
#  else
#   define SIMD_INLINE  inline
#  endif
#  if __has_attribute(__const__)
#   define SIMD_CONST   __attribute__((__const__))
#  else
#   define SIMD_CONST   /* nothing */
#  endif
#  if __has_attribute(__nodebug__)
#   define SIMD_NODEBUG __attribute__((__nodebug__))
#  else
#   define SIMD_NODEBUG /* nothing */
#  endif
#  if __has_attribute(__deprecated__)
#   define SIMD_DEPRECATED(message) __attribute__((__deprecated__(message)))
#  else
#   define SIMD_DEPRECATED(message) /* nothing */
#  endif
#define SIMD_OVERLOAD __attribute__((__overloadable__))
#define SIMD_CPPFUNC  SIMD_INLINE SIMD_CONST SIMD_NODEBUG
#define SIMD_CFUNC    SIMD_CPPFUNC SIMD_OVERLOAD
#define SIMD_NOINLINE SIMD_CONST SIMD_NODEBUG SIMD_OVERLOAD
#define SIMD_NONCONST SIMD_INLINE SIMD_NODEBUG SIMD_OVERLOAD
#define __SIMD_INLINE__     SIMD_CPPFUNC
#define __SIMD_ATTRIBUTES__ SIMD_CFUNC
#define __SIMD_OVERLOAD__   SIMD_OVERLOAD
#  if __has_feature(cxx_constexpr)
#   define SIMD_CONSTEXPR constexpr
#  else
#   define SIMD_CONSTEXPR /* nothing */
#  endif
#  if __has_feature(cxx_noexcept)
#   define SIMD_NOEXCEPT noexcept
#  else
#   define SIMD_NOEXCEPT /* nothing */
#  endif
#if defined __cplusplus
typedef  bool simd_bool;
#else
typedef _Bool simd_bool;
#endif
typedef simd_bool __SIMD_BOOLEAN_TYPE__;
# endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* defined SIMD_BASE */
