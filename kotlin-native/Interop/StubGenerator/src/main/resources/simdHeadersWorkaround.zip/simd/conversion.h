#ifndef __SIMD_CONVERSION_HEADER__
#define __SIMD_CONVERSION_HEADER__
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector_types.h>
#include <simd/common.h>
#include <simd/logic.h>
#ifdef __cplusplus
#endif
#define vector_char simd_char
#define vector_char_sat simd_char_sat
#define vector_uchar simd_uchar
#define vector_uchar_sat simd_uchar_sat
#define vector_short simd_short
#define vector_short_sat simd_short_sat
#define vector_ushort simd_ushort
#define vector_ushort_sat simd_ushort_sat
#define vector_int simd_int
#define vector_int_sat simd_int_sat
#define vector_uint simd_uint
#define vector_uint_sat simd_uint_sat
#define vector_float simd_float
#define vector_long simd_long
#define vector_long_sat simd_long_sat
#define vector_ulong simd_ulong
#define vector_ulong_sat simd_ulong_sat
#define vector_double simd_double
#pragma mark - Implementation
#if defined __arm64__
#else
#endif
#if defined __SSE2__
#elif defined __arm64__
#else
#endif
#if defined __AVX__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512F__
#elif defined __arm64__
#else
#endif
#if defined __AVX512F__
#else
#endif
#if defined __AVX512F__
#else
#endif
#ifdef __cplusplus
#if __has_feature(cxx_constexpr)
#endif /* __has_feature(cxx_constexpr) */
#endif // __cplusplus
#endif // SIMD_COMPILER_HAS_REQUIRED_FEATURES
#endif // __SIMD_CONVERSION_HEADER__
