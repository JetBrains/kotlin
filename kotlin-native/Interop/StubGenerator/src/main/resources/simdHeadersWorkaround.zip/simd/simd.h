#ifndef __SIMD_HEADER__
#define __SIMD_HEADER__
#if __has_include(<realtime_safety/realtime_safety.h>)
#include <realtime_safety/realtime_safety.h>
#endif
#include <simd/vector.h>
#include <simd/matrix.h>
#include <simd/quaternion.h>
#if __has_include(<realtime_safety/realtime_safety.h>)
#endif
#endif
