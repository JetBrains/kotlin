#ifndef SIMD_QUATERNIONS
#define SIMD_QUATERNIONS
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/vector.h>
#include <simd/types.h>
#ifdef __cplusplus
#endif
#ifdef __cplusplus
#endif /* __cplusplus */
#include <simd/math.h>
#include <simd/geometry.h>
#if defined __arm__ || defined __arm64__
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#ifdef __cplusplus
#endif /* __cplusplus */
#include <simd/math.h>
#include <simd/geometry.h>
#if defined __arm__ || defined __arm64__
#endif
#if defined __arm__ || defined __arm64__
#else
#endif
#ifdef __cplusplus
#endif /* __cplusplus */
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* SIMD_QUATERNIONS */
