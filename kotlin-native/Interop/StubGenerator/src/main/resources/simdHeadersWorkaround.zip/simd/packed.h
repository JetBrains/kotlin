#ifndef SIMD_PACKED_TYPES
#define SIMD_PACKED_TYPES
# include <simd/vector_types.h>
# if SIMD_COMPILER_HAS_REQUIRED_FEATURES
typedef __attribute__((__ext_vector_type__(2),__aligned__(1))) char simd_packed_char2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(1))) char simd_packed_char4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(1))) char simd_packed_char8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(1))) char simd_packed_char16;
typedef __attribute__((__ext_vector_type__(32),__aligned__(1))) char simd_packed_char32;
typedef __attribute__((__ext_vector_type__(64),__aligned__(1))) char simd_packed_char64;
typedef __attribute__((__ext_vector_type__(2),__aligned__(1))) unsigned char simd_packed_uchar2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(1))) unsigned char simd_packed_uchar4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(1))) unsigned char simd_packed_uchar8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(1))) unsigned char simd_packed_uchar16;
typedef __attribute__((__ext_vector_type__(32),__aligned__(1))) unsigned char simd_packed_uchar32;
typedef __attribute__((__ext_vector_type__(64),__aligned__(1))) unsigned char simd_packed_uchar64;
typedef __attribute__((__ext_vector_type__(2),__aligned__(2))) short simd_packed_short2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(2))) short simd_packed_short4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(2))) short simd_packed_short8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(2))) short simd_packed_short16;
typedef __attribute__((__ext_vector_type__(32),__aligned__(2))) short simd_packed_short32;
typedef __attribute__((__ext_vector_type__(2),__aligned__(2))) unsigned short simd_packed_ushort2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(2))) unsigned short simd_packed_ushort4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(2))) unsigned short simd_packed_ushort8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(2))) unsigned short simd_packed_ushort16;
typedef __attribute__((__ext_vector_type__(32),__aligned__(2))) unsigned short simd_packed_ushort32;
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) int simd_packed_int2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) int simd_packed_int4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) int simd_packed_int8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(4))) int simd_packed_int16;
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) unsigned int simd_packed_uint2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) unsigned int simd_packed_uint4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) unsigned int simd_packed_uint8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(4))) unsigned int simd_packed_uint16;
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) float simd_packed_float2;
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) float simd_packed_float4;
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) float simd_packed_float8;
typedef __attribute__((__ext_vector_type__(16),__aligned__(4))) float simd_packed_float16;
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(2),__aligned__(8))) simd_long1 simd_packed_long2;
#else
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) simd_long1 simd_packed_long2;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(4),__aligned__(8))) simd_long1 simd_packed_long4;
#else
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) simd_long1 simd_packed_long4;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(8),__aligned__(8))) simd_long1 simd_packed_long8;
#else
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) simd_long1 simd_packed_long8;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(2),__aligned__(8))) simd_ulong1 simd_packed_ulong2;
#else
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) simd_ulong1 simd_packed_ulong2;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(4),__aligned__(8))) simd_ulong1 simd_packed_ulong4;
#else
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) simd_ulong1 simd_packed_ulong4;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(8),__aligned__(8))) simd_ulong1 simd_packed_ulong8;
#else
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) simd_ulong1 simd_packed_ulong8;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(2),__aligned__(8))) double simd_packed_double2;
#else
typedef __attribute__((__ext_vector_type__(2),__aligned__(4))) double simd_packed_double2;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(4),__aligned__(8))) double simd_packed_double4;
#else
typedef __attribute__((__ext_vector_type__(4),__aligned__(4))) double simd_packed_double4;
#endif
#if defined __LP64__
typedef __attribute__((__ext_vector_type__(8),__aligned__(8))) double simd_packed_double8;
#else
typedef __attribute__((__ext_vector_type__(8),__aligned__(4))) double simd_packed_double8;
#endif
#if defined __cplusplus
typedef ::simd_packed_char2 char2;
typedef ::simd_packed_char4 char4;
typedef ::simd_packed_char8 char8;
typedef ::simd_packed_char16 char16;
typedef ::simd_packed_char32 char32;
typedef ::simd_packed_char64 char64;
typedef ::simd_packed_uchar2 uchar2;
typedef ::simd_packed_uchar4 uchar4;
typedef ::simd_packed_uchar8 uchar8;
typedef ::simd_packed_uchar16 uchar16;
typedef ::simd_packed_uchar32 uchar32;
typedef ::simd_packed_uchar64 uchar64;
typedef ::simd_packed_short2 short2;
typedef ::simd_packed_short4 short4;
typedef ::simd_packed_short8 short8;
typedef ::simd_packed_short16 short16;
typedef ::simd_packed_short32 short32;
typedef ::simd_packed_ushort2 ushort2;
typedef ::simd_packed_ushort4 ushort4;
typedef ::simd_packed_ushort8 ushort8;
typedef ::simd_packed_ushort16 ushort16;
typedef ::simd_packed_ushort32 ushort32;
typedef ::simd_packed_int2 int2;
typedef ::simd_packed_int4 int4;
typedef ::simd_packed_int8 int8;
typedef ::simd_packed_int16 int16;
typedef ::simd_packed_uint2 uint2;
typedef ::simd_packed_uint4 uint4;
typedef ::simd_packed_uint8 uint8;
typedef ::simd_packed_uint16 uint16;
typedef ::simd_packed_float2 float2;
typedef ::simd_packed_float4 float4;
typedef ::simd_packed_float8 float8;
typedef ::simd_packed_float16 float16;
typedef ::simd_packed_long2 long2;
typedef ::simd_packed_long4 long4;
typedef ::simd_packed_long8 long8;
typedef ::simd_packed_ulong2 ulong2;
typedef ::simd_packed_ulong4 ulong4;
typedef ::simd_packed_ulong8 ulong8;
typedef ::simd_packed_double2 double2;
typedef ::simd_packed_double4 double4;
typedef ::simd_packed_double8 double8;
#endif /* __cplusplus                                                         */
typedef simd_packed_char2 packed_char2;
typedef simd_packed_char4 packed_char4;
typedef simd_packed_char8 packed_char8;
typedef simd_packed_char16 packed_char16;
typedef simd_packed_char32 packed_char32;
typedef simd_packed_char64 packed_char64;
typedef simd_packed_uchar2 packed_uchar2;
typedef simd_packed_uchar4 packed_uchar4;
typedef simd_packed_uchar8 packed_uchar8;
typedef simd_packed_uchar16 packed_uchar16;
typedef simd_packed_uchar32 packed_uchar32;
typedef simd_packed_uchar64 packed_uchar64;
typedef simd_packed_short2 packed_short2;
typedef simd_packed_short4 packed_short4;
typedef simd_packed_short8 packed_short8;
typedef simd_packed_short16 packed_short16;
typedef simd_packed_short32 packed_short32;
typedef simd_packed_ushort2 packed_ushort2;
typedef simd_packed_ushort4 packed_ushort4;
typedef simd_packed_ushort8 packed_ushort8;
typedef simd_packed_ushort16 packed_ushort16;
typedef simd_packed_ushort32 packed_ushort32;
typedef simd_packed_int2 packed_int2;
typedef simd_packed_int4 packed_int4;
typedef simd_packed_int8 packed_int8;
typedef simd_packed_int16 packed_int16;
typedef simd_packed_uint2 packed_uint2;
typedef simd_packed_uint4 packed_uint4;
typedef simd_packed_uint8 packed_uint8;
typedef simd_packed_uint16 packed_uint16;
typedef simd_packed_float2 packed_float2;
typedef simd_packed_float4 packed_float4;
typedef simd_packed_float8 packed_float8;
typedef simd_packed_float16 packed_float16;
typedef simd_packed_long2 packed_long2;
typedef simd_packed_long4 packed_long4;
typedef simd_packed_long8 packed_long8;
typedef simd_packed_ulong2 packed_ulong2;
typedef simd_packed_ulong4 packed_ulong4;
typedef simd_packed_ulong8 packed_ulong8;
typedef simd_packed_double2 packed_double2;
typedef simd_packed_double4 packed_double4;
typedef simd_packed_double8 packed_double8;
# endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif
