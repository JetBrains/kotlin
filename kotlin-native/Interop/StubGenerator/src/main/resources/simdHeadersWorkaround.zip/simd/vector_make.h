#ifndef SIMD_VECTOR_CONSTRUCTORS
#define SIMD_VECTOR_CONSTRUCTORS
#include <simd/vector_types.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#ifdef __cplusplus
#endif
#ifdef __cplusplus
#include <tuple>
#include <simd/packed.h>
#if __has_feature(cxx_constexpr)
#endif /* __has_feature(cxx_constexpr) */
#endif /* __cplusplus */
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* SIMD_VECTOR_CONSTRUCTORS */
