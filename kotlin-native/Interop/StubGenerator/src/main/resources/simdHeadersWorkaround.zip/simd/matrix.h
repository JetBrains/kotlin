#ifndef SIMD_MATRIX_HEADER
#define SIMD_MATRIX_HEADER
#include <simd/base.h>
#if SIMD_COMPILER_HAS_REQUIRED_FEATURES
#include <simd/matrix_types.h>
#include <simd/geometry.h>
#include <simd/extern.h>
#include <simd/logic.h>
#ifdef __cplusplus
#endif
#define matrix_from_diagonal simd_diagonal_matrix
#define matrix_from_columns simd_matrix
#define matrix_from_rows simd_matrix_from_rows
#define matrix_linear_combination simd_linear_combination
#define matrix_add simd_add
#define matrix_sub simd_sub
#define matrix_transpose simd_transpose
#define matrix_trace simd_trace
#define matrix_determinant simd_determinant
#define matrix_invert simd_inverse
#define matrix_equal simd_equal
#define matrix_almost_equal_elements simd_almost_equal_elements
#define matrix_almost_equal_elements_relative simd_almost_equal_elements_relative
#ifdef __cplusplus
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wgcc-compat"
#pragma clang diagnostic pop
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wgcc-compat"
#pragma clang diagnostic pop
#endif /* __cplusplus */
#pragma mark - Implementation
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __SSE__
#elif defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#if defined __ARM_NEON__ && defined __arm64__
#else
#endif
#ifdef __cplusplus
#endif
#endif /* SIMD_COMPILER_HAS_REQUIRED_FEATURES */
#endif /* __SIMD_HEADER__ */
